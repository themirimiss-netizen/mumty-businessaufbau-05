---
name: sales-page-bauen
description: Baut eine ausführliche Verkaufsseite (Sales Page) für höherpreisige MUMTY-Angebote wie Flugsimulator, AlphaMUM oder 1:1 Mastermind – im Unterschied zur schlankeren Landingpage. Nutze diesen Skill, wenn ein Angebot ab ca. 250€ eine eigene, ausführliche Verkaufsseite mit Einwandbehandlung braucht, nicht nur eine kurze Landingpage.
---

# Sales Page bauen (MUMTY)

Für Angebote, bei denen die Kaufentscheidung mehr Vertrauen und mehr Informationen braucht als eine schlanke Landingpage liefern kann: Flugsimulator (280€), AlphaMUM (4.000–6.000€), ggf. 1:1 Mastermind als "Anfrage"-Seite statt Kaufseite.

## Unterschied zur Landingpage
Landingpage (siehe `landingpage-bauen`): kurz, ein CTA, wenig Einwandbehandlung, meist für Freebies/Low-Ticket.
Sales Page: lang, mehrere CTAs im Seitenverlauf, ausführliche Einwandbehandlung, Storytelling, Social Proof, FAQ – weil die Kaufentscheidung größer ist.

## Voraussetzung
Positionierung für das jeweilige Angebot muss stehen (siehe `positionierung-schaerfen`), Preis muss feststehen (siehe `preisstrategie`). Ohne beides wird die Sales Page beliebig.

## Bewährte Struktur (lang genug für High-Ticket)

1. **Hero** – Kernversprechen + wer das liest (nicht generisch, siehe Positionierungssatz)
2. **Problem tief ausbreiten** – die Kundin muss sich wiedererkennen, bevor sie weiterliest
3. **Warum bisherige Lösungen nicht gereicht haben** – Abgrenzung zu "einfach mehr Content konsumieren"
4. **Die Wende/das neue Verständnis** – der Kern-Shift, den MUMTY bringt
5. **Vorstellung des Angebots** – konkret: Format, Dauer, was drin ist
6. **Transformation/Ergebnis** – was ist danach anders (konkret, keine Floskeln)
7. **Für-wen-ist-das / für-wen-nicht** – Selbstselektion, spart spätere Enttäuschung
8. **Ablauf/Modulübersicht** – Struktur schafft Vertrauen bei höheren Preisen
9. **Preis & Investition** – siehe `preisstrategie` für Formulierung, Ratenoption nennen
10. **Über Miriam** – persönliche Geschichte, Vertrauen, kein Lebenslauf
11. **Testimonials/Erfahrungen** – siehe `testimonials-sammeln`, nur mit echter Einwilligung
12. **Einwände (FAQ)** – die 5-8 häufigsten Zweifel aktiv ansprechen, nicht verstecken ("Ich habe keine Zeit", "Ich weiß nicht ob ich bereit bin", "Was wenn es nicht funktioniert")
13. **Letzter CTA** – Dringlichkeit nur, wenn sie echt ist (echte Warteliste/echtes Startdatum, keine erfundene Verknappung)
14. **Footer** – Impressum/Datenschutz-Link (siehe `coaching-vertrag-verstehen` für rechtliche Basis)

## Bau-Prompt für Claude Code

```
Du baust mir jetzt eine ausführliche Sales Page für [Angebotsname]. Lies erst
alles, bau danach.

FUNDAMENT
Positionierungssatz: [aus positionierung-schaerfen]
Preis & Ratenoption: [aus preisstrategie]
Mein Sprachstil: [aus brand-voice, falls vorhanden]

STRUKTUR
[obige 14 Abschnitte, ggf. anpassen wenn ein Abschnitt bei diesem Angebot
nicht passt]

WICHTIG
Kein Coach-Sprech ("Herzensbusiness", "soulful", "Raum für Transformation").
Konkret, direkt, kurze Sätze. Einwände ehrlich ansprechen, nicht wegreden.

WAS NOCH FEHLT
Testimonials, Bilder, exakter Preis falls noch offen – Platzhalter setzen,
am Ende auflisten.

Leg alle Dateien hier ab: [Repository-Ordner]
```

## Häufiger Fehler
Sales Page wird zur Landingpage verkürzt, weil "lang = schlecht" gefühlt wird. Bei Preisen ab 280€ aufwärts ist Länge kein Problem, sondern nötig – die Leserin, die wirklich kaufen will, liest zu Ende. Kürzen hilft nur, wenn Inhalt nichts zur Kaufentscheidung beiträgt, nicht weil er lang ist.
