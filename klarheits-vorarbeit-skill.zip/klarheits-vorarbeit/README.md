# Skill: `klarheits-vorarbeit` — Setup für deine Claude-Welt

Dieser Skill ist dein **15-Minuten-Klarheits-Coach**, bevor du eine Landingpage / Conversion-Page mit Claude baust. Er stellt dir die richtigen Fragen, nutzt was er aus deinem Profil schon weiß, und spuckt am Ende ein vollständiges Briefing + einen Magic-Prompt für Claude Code aus.

---

## ⚠️ Voraussetzungen — bevor du startest

Lies das einmal in Ruhe. Wenn alle 4 Häkchen gesetzt sind, funktioniert der Skill perfekt.

### 1. Claude-Plan: Pro, Max, Team oder Enterprise
- ❌ Funktioniert NICHT mit Free
- ✅ Pro (20 $/Monat) reicht völlig

### 2. „Code Execution" aktivieren
Das ist die versteckte Einstellung, ohne die Skills nicht laufen:
- Claude.ai öffnen → unten links auf dein Profil-Icon → **Settings**
- Tab **„Capabilities"** auswählen
- **„Code Execution"** Toggle einschalten ✓

→ Falls du den Toggle nicht siehst: vermutlich falscher Plan. Pro-Plan benötigt.

### 3. Skill installieren
- Diesen Ordner (`klarheits-vorarbeit`) als ZIP speichern
- Claude.ai → Settings → **Customize** (oder „Anpassen") → **Skills**
- **„Upload Skill"** → ZIP hochladen
- Skill ist ab jetzt in allen deinen Chats verfügbar

### 4. Claude-Projekt mit deinem Profil
Der Skill wird viel besser, wenn er weiß WER DU BIST. Dafür legst du EINMAL ein Projekt an:

- Claude.ai → linke Seitenleiste → **Projects** → **„New Project"**
- Name z.B. „Mein Business"
- **„Add Knowledge"** (Projekt-Wissen) → 3 Dateien hochladen:
  - `positionierung.md` (1 Seite: Wer bin ich, für wen, wofür)
  - `avatar.md` oder `traumkundin.md` (1 Seite: Wer ist meine Wunsch-Kundin)
  - `voice.md` oder `brand-voice.md` (1 Seite: Tonart + Brand-Farben Hex-Codes)

→ Wenn du diese 3 Dateien noch nicht hast: nutze zuerst den **`brand-voice-light`-Skill** (kommt im Webseiten-Helferlein-Kurs, Modul 3). Der erstellt sie für dich.

---

## So nutzt du den Skill

1. **Im Claude-Projekt** einen neuen Chat öffnen *(nicht im freien Chat ohne Projekt — dort fehlt dem Skill der Kontext)*
2. Sage: *„Klarheits-Vorarbeit für [Page-Typ — z.B. Workshop-Anmeldung]"*
3. Skill startet automatisch
4. Beantworte die Fragen (eine nach der anderen)
5. Am Ende kriegst du:
   - Ein **vollständiges Briefing** als Markdown-Block
   - Einen **Magic-Prompt** für Claude Code zum direkten Bauen
   - Einen **Ready-Check-Satz** zum Selbst-Test

---

## Was wenn du Free-Plan hast?

**Du kannst diesen Skill nicht installieren.** Aber: Du kannst die Klarheits-Vorarbeit auch **als Projekt-Anweisung manuell einrichten**. So geht's:

- Claude-Projekt anlegen (geht auch im Free-Plan)
- In den Projekt-Anweisungen folgenden Text einfügen:

```
Du bist mein Klarheits-Coach für Landingpage-Briefings.
Stelle mir nacheinander folgende Fragen:
1. Welche Page baue ich (Freebie/Workshop/Kurs/Erstgespräch/Warteliste)?
2. Wer bin ich und was verkaufe ich? (Falls im Projekt-Wissen — daraus übernehmen)
3. Was hat die Kundin am Ende konkret in der Hand? (Dream Outcome)
4. Für wen genau? + Awareness-Level (Problem/Solution/Product-aware)
5. Was nervt sie? (Schmerz: extern + intern + schlechte Alternative)
6. Was macht mich anders? (3 Punkte)
7. Haupteinwand + Antwort
8. CTA: Was soll sie tun? Was passiert nach Klick?
9. Brand-Farben + Visuals?
10. Tech: Domain, Hosting, Bezahlung?

Eine Frage nach der anderen. Bei vagen Antworten nachhaken.
Am Ende: vollständiges Briefing + Magic-Prompt für Claude Code.
```

Funktioniert ähnlich gut, ist nur weniger smart bei Wiederverwendung.

---

## Häufige Stolperfallen

| Problem | Lösung |
|---------|--------|
| Skill triggert nicht | Du arbeitest im freien Chat, nicht im Projekt. Wechsel ins Projekt. |
| Skill stellt Fragen die er schon wissen müsste | Projekt-Wissen ist nicht da oder unvollständig. Lade Positionierung/Avatar/Voice hoch. |
| Skill sagt „Code Execution nicht aktiviert" | Settings → Capabilities → Toggle einschalten. |
| Skill stellt 12 Fragen statt 7 | Phase −1 ist übersprungen worden, weil kein Profil im Kontext. Lade die 3 Dateien hoch. |

---

## Update

Wenn eine neue Version dieses Skills kommt:
1. Alte Version in Claude.ai löschen (Settings → Skills → Delete)
2. Neue ZIP hochladen
3. Fertig

---

## Was dieser Skill NICHT macht

- Er baut die Page nicht selbst — das macht Claude Code (oder Claude.ai mit Web-Suche) mit dem Magic-Prompt am Ende
- Er erstellt keine Brand-Voice / Positionierung — dafür gibt es den `brand-voice-light` Skill
- Er prüft die fertige Page nicht — das macht später der `deploy-check` Skill (kommt in Modul 6 des Kurses)

---

**Bei Fragen oder Bugs:** gina.selent@gs-selent.de oder im Webseiten-Helferlein-Support-Bereich.
