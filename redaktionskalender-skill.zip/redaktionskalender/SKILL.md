---
name: redaktionskalender
description: Erstellt einen Redaktionskalender/Content-Plan für Instagram, LinkedIn, Facebook und Newsletter in der MUMTY Brand Voice. Nutze diesen Skill, wenn Miriam einen Content-Monat planen, Themen auf Kanäle verteilen, oder einen Newsletter nach dem MUMTY-Raster schreiben möchte.
---

# Redaktionskalender MUMTY

Baut aus Rohideen (Themen, Beobachtungen, Kundinnen-Momente) einen strukturierten Content-Plan über mehrere Kanäle.

## Ablauf

1. **Rohmaterial sammeln**: Themen, Beobachtungen, aktuelle Kundinnen-Situationen (anonymisiert), geplante Launches/Termine (z.B. AlphaMUM-Meilensteine, Gastredner-Termine)
2. **Kernbotschaft pro Beitrag prüfen**: Passt der Inhalt zum Kernsatz? ("AlphaMUM ist für Frauen, die alles wissen, alles können — und sich trotzdem immer wieder selbst davon abhalten, damit Geld zu verdienen.") Wenn nicht, aussortieren oder umbauen.
3. **Auf Kanäle verteilen**: Nicht jedes Thema auf jeden Kanal – je nach Format passend zuordnen (Instagram: kurz, visuell; LinkedIn: reflektierter, beruflicher Rahmen; Newsletter: persönlich, tiefer)
4. **Newsletter nach MUMTY-Raster bauen** (siehe unten)
5. **Kalender ausgeben**: Datum, Kanal, Thema, Kernaussage, CTA – als Tabelle oder Liste, je nach Wunsch

## MUMTY-Newsletter-Raster

Jeder Newsletter folgt dieser Struktur, nicht dem generischen Marketing-Aufbau:

1. **Aufhänger** – eine kleine, persönliche Beobachtung/Situation (Alltag, Kundinnen-Session, Call). Kein "Hallo zusammen", direkt rein.
2. **Die Wendung** – der Punkt, an dem die Beobachtung zur größeren Wahrheit über Identität/Business wird (Prinzip: nicht fehlendes Wissen, sondern fehlende unternehmerische Identität ist das Problem)
3. **Konkreter Gedanke/Impuls** – etwas, das die Leserin direkt mitnehmen und anwenden kann
4. **CTA** – ein Satz, kein Verkaufsblock (Schatzfinder-Quiz, AlphaMUM-Warteliste, oder "antworte mir")

## Ton- und Stilregeln (immer einhalten)

- Du-Form, kurze Sätze, keine akademische Sprache
- Keine generischen Coaching-Buzzwords ("Klarheit", "Mindset-Shift" o.ä.)
- Emotionale Tiefe und konkrete persönliche Framing statt Floskeln
- Anti-KI-Regeln beachten, falls Brand-Voice-Profil vorhanden: keine Dreierketten auf Autopilot, keine "Zusammenfassend lässt sich sagen"-Formulierungen

## Output-Format

Standardmäßig als Tabelle: Datum | Kanal | Thema | Kernaussage | Format (Post/Story/Newsletter) | CTA

Bei Bedarf zusätzlich: einzelne Newsletter oder Posts direkt ausformulieren, nicht nur als Stichpunkt.

## Wichtig

Vor dem Erstellen: prüfen, ob aktuelle Termine/Meilensteine (Launches, Gastredner, Deadlines) im Kalender berücksichtigt werden müssen. Bei Unklarheit über Zeitraum, Anzahl Beiträge pro Woche, oder Kanalpriorität: nachfragen statt raten.
