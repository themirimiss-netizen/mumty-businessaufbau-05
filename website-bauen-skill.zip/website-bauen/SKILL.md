---
name: website-bauen
description: Baut mit Claude eine eigene Website – One-Pager oder mehrseitig (Home, Über mich, Angebote, Kontakt, Impressum) – von der Einrichtung bis zum Live-Gang. Eigenständiger Skill, funktioniert auch ohne andere Business-Ordner oder Vorlagen. Nutze diesen Skill, wenn jemand eine eigene Website bauen, überarbeiten oder live stellen möchte, egal ob schon Cowork/GitHub/Netlify eingerichtet sind oder nicht.
---

# Website bauen: Deine eigene Website mit Claude

Für Unternehmerinnen, die ihre Website selbst bauen wollen – ohne Programmierer, ohne teure Agentur, ohne monatelanges Warten. Dieser Skill funktioniert für dich alleine, komplett unabhängig von anderen Vorlagen.

## Schritt 0: Kurz-Check

Frag die Nutzerin direkt am Anfang:

```
Bevor wir starten, zwei kurze Fragen:

1. Hast du schon einen GitHub-Account und Netlify verbunden? (Falls du nicht
   weißt was das ist: nein, hast du nicht – dann machen wir das zuerst kurz.)
2. Soll deine Website eine Seite sein mit mehreren Bereichen (One-Pager) oder
   mehrere Unterseiten (Home, Über mich, Angebote, Kontakt)?
```

Je nach Antwort: bei "nein, kein Setup" → erst Teil A. Bei "ja, hab ich schon" → direkt zu Teil B.

---

## Teil A: Einmalige Einrichtung (nur falls noch nicht vorhanden)

Das hier machst du nur EINMAL. Danach brauchst du für jede weitere Website oder Änderung nur noch Teil B–E.

### A1. Claude einrichten (~15 Min)
- Account auf claude.ai, Pro-Plan reicht völlig (kein Max nötig für den Start)
- Desktop-App installieren – für Cowork und Claude Code brauchst du die Desktop-App, nicht nur den Browser
- In den Einstellungen: Datentraining auf "Aus" stellen (Datenschutz), und unter "Persönliche Präferenzen" reinschreiben: "Stell mir Rückfragen, wenn dir etwas unklar ist. Keine KI-Floskeln, keine Buzzwords."

### A2. GitHub einrichten (~15 Min)
- Account auf github.com anlegen (kostenlos)
- GitHub Desktop installieren (die App, nicht nur die Website)
- Ein neues Repository anlegen, Name z.B. `meine-website`

### A3. Netlify einrichten (~10 Min)
- Account auf netlify.com anlegen, dabei "Mit GitHub anmelden" wählen (nicht extra Passwort)
- Neues Projekt anlegen, das eben erstellte GitHub-Repository verbinden

### A4. Magie-Test (~5 Min)
Eine leere `index.html` mit dem Text "Hallo Welt" in den lokalen Repository-Ordner legen → in GitHub Desktop einen Commit machen ("erste Version") → Push klicken → 30 Sekunden warten → die Netlify-Adresse öffnen. Steht dort "Hallo Welt"? Dann funktioniert die ganze Kette. Das ist der wichtigste Test überhaupt – wenn der klappt, klappt alles Weitere auch.

**Troubleshooting Setup:**

| Symptom | Fix |
|---|---|
| GitHub Desktop findet Repository nicht | Repository erst auf github.com anlegen, dann in Desktop klonen |
| Netlify zeigt "Page not found" | Ordner war beim ersten Deploy leer – nochmal pushen |
| Nichts passiert nach Push | 30-60 Sek. warten, Netlify braucht kurz zum Bauen |

---

## Teil B: Website-Typ wählen

### One-Pager (eine Seite, mehrere Bereiche)
Passend für: ein einzelnes Angebot, ein Freebie, eine Bewerbungsseite für ein Programm, wenn Einfachheit wichtiger ist als Tiefe.

Typische Bereiche: Hero → Problem → Lösung/Angebot → Für-wen → Ablauf → Preis/CTA → Vertrauen (über dich) → FAQ → Footer mit Impressum-Link.

### Mehrseitige Website
Passend für: das gesamte Business/die Marke, mehrere Angebote gleichzeitig, wenn Besucherinnen gezielt navigieren sollen.

Typische Seiten:
- **Home** – Einstieg, Übersicht, Weg zu allen anderen Seiten
- **Über mich** – Persönlichkeit, Werdegang, Vertrauen
- **Angebote/Programme** – eine Seite pro Angebot oder eine Übersicht mit Verlinkung
- **Kontakt** – Formular oder Buchungslink (z.B. Calendly)
- **Impressum & Datenschutz** – Pflicht in Deutschland (siehe Teil F)

**Faustregel bei Unsicherheit:** hat sie EIN Angebot → One-Pager reicht. Hat sie mehrere Angebote oder eine wachsende Marke → mehrseitig.

---

## Teil C: Inhalte vorbereiten

Das ist der Teil, der am meisten über die Qualität der fertigen Website entscheidet – nicht das Design. Bevor Claude irgendetwas baut, muss dieses Fundament stehen.

### C1. Positionierung & Zielgruppe (~20 Min)

Lass dir von Claude im normalen Chat folgende Fragen stellen (oder stell sie der Nutzerin direkt):

```
Beantworte mir kurz, in Stichworten reicht:

1. Was genau bietest du an? (Ein Satz)
2. Für wen ist das? Wer ist deine Wunschkundin, konkret?
3. Was ist ihr größtes Problem, bevor sie zu dir kommt?
4. Was hat sie danach, was sie vorher nicht hatte?
5. Warum du und nicht jemand anderes? Was macht dich anders?
```

### C2. Eigene Sprache einfangen (~15 Min)

Wichtigster Schritt gegen generische KI-Texte. Sammle 3-5 eigene Texte (Social-Media-Posts, E-Mails an Kundinnen, Sprachnachrichten transkribiert) und gib sie Claude:

```
Hier sind ein paar Texte von mir, so wie ich wirklich schreibe/spreche.
Analysier meinen Stil: Satzlänge, Wortwahl, was ich NIE sagen würde,
welche Ausdrücke typisch für mich sind.

Halt das kurz als Merkzettel fest, den du bei allen weiteren Texten für
mich anwendest.

[Texte einfügen]
```

**Wichtig:** Coach-Sprech wie "Herzensbusiness", "soulful", "Raum für Tiefe und Transformation", "Bewegung für Frauen" klingt nach jedem zweiten Coach im Internet. Wenn Claude das von sich aus vorschlägt: streichen und konkreter, direkter formulieren lassen.

### C3. Papageien-Test (~15 Min, mit einer echten Person)

Angebot/Kernbotschaft in 90 Sekunden einer Person erklären. Die Person fasst danach in einem Satz zusammen: "Du machst …". Trifft es? Falls nicht: zurück zu C1, Positionierung schärfen.

---

## Teil D: Bau-Prompt (Magic Prompt)

Das hier läuft in **Claude Code** (Desktop-App, nicht im normalen Chat-Fenster). Vorher alle eckigen Klammern durch echte Werte ersetzen.

### Bei One-Pager:

```
Du baust mir jetzt meine Website. Lies erst alles, bau danach.

MEIN FUNDAMENT
Angebot: [aus C1]
Zielgruppe: [aus C1]
Problem/Nutzen: [aus C1]
Mein Sprachstil: [Merkzettel aus C2]

WAS DU BAUEN SOLLST
Eine Seite mit diesen Bereichen, in dieser Reihenfolge:
Hero, Problem, Lösung/Angebot, Für-wen-ist-das, Ablauf, Preis & CTA,
Über mich (kurz), FAQ, Footer mit Impressum/Datenschutz-Link.

DESIGN
[Farben/Stil beschreiben, z.B. "warm, elegant, Sage-Grün, Rosé, Cream,
Serifenschrift für Überschriften" – oder: "schau dir [Beispiel-Link] an,
in diese Richtung"]

WAS DU NOCH NICHT HAST
Bilder, Logo, Buchungslink. Setz klar erkennbare Platzhalter, sag mir am
Ende was ich nachliefern muss.

BEVOR DU LOSLEGST
Stell mir Rückfragen, wenn dir etwas fehlt oder unklar ist. Schreib NICHT
in generischem Coach-Sprech, sondern in meinem Stil (siehe oben).

Leg alle fertigen Dateien hier ab: [Repository-Ordner]
```

### Bei mehrseitiger Website:

```
Du baust mir jetzt meine Website. Lies erst alles, bau danach.

MEIN FUNDAMENT
Angebot(e): [aus C1, ggf. mehrere Angebote einzeln auflisten]
Zielgruppe: [aus C1]
Problem/Nutzen: [aus C1]
Mein Sprachstil: [Merkzettel aus C2]

SEITENSTRUKTUR
Home, Über mich, Angebote (eine Übersicht + ggf. eigene Unterseite pro
Angebot), Kontakt, Impressum, Datenschutz.

Home soll auf alle anderen Seiten verlinken und einen klaren roten
Faden zu den Angeboten haben, nicht nur lose nebeneinander stehen.

DESIGN
[wie oben]

WAS DU NOCH NICHT HAST
Bilder, Logo, Buchungslink, rechtliche Texte für Impressum/Datenschutz
(kommen in Teil F). Platzhalter setzen, am Ende auflisten was fehlt.

BEVOR DU LOSLEGST
Stell mir Rückfragen. Schreib in meinem Stil, nicht generisch.

Leg alle fertigen Dateien hier ab: [Repository-Ordner]
```

---

## Teil E: Rechtliches – Impressum & Datenschutz

**Für Deutschland/Österreich/Schweiz Pflicht auf jeder gewerblichen Website.** Claude kann keine Rechtsberatung geben – die Texte müssen von einer echten Quelle kommen:

- **IT-Recht Kanzlei** (kostenpflichtiger Rechtstext-Generator, gängigster Weg)
- **e-recht24.de** (kostenlose Basis-Generatoren, für den Start okay)
- Bei eigenem Rechtsanwalt/Steuerberater nachfragen, ob er/sie Texte bereitstellt

Fertigen Text einfach einfügen lassen: "Hier ist mein fertiger Impressum-Text von [Quelle]. Bau ihn technisch sauber ein, z.B. als eigene Unterseite oder Footer-Modal." Claude soll den Text **wörtlich übernehmen**, nicht umformulieren – das ist Rechtstext, kein Marketingtext.

---

## Teil F: Live stellen (~5 Min)

GitHub Desktop öffnen → Änderungen sind sichtbar → kurze Beschreibung eintragen (z.B. "Website erste Version") → Commit → Push → 30 Sekunden warten → Netlify-Adresse öffnen → live.

Für jede weitere Änderung: gleicher Ablauf. Datei ändern (lassen) → Commit → Push → online.

---

## Teil G: Eigene Domain verbinden (optional, ganz am Schluss)

Die Website funktioniert auch ohne eigene Domain (unter der `netlify.app`-Adresse). Wenn eine eigene Domain gewünscht ist:

1. Domain bei einem Anbieter registrieren/vorhanden (z.B. IONOS, Namecheap, Netlify selbst)
2. Bei Netlify unter "Domain settings" die eigene Domain hinzufügen
3. Netlify zeigt an, welche DNS-Einträge (A-Record, CNAME) beim Domain-Anbieter gesetzt werden müssen
4. **Wichtig bei bestehender Domain mit E-Mail-Postfach:** MX-, DKIM-, SPF- und DMARC-Einträge unbedingt unangetastet lassen, sonst geht die E-Mail-Funktion kaputt. Nur die A/CNAME-Einträge für die Website ändern.
5. Bis zu 24 Std. warten bis die Domain überall greift (DNS-Propagation)

**Backup-Sicherheit:** Weil die Website jetzt als Datei im GitHub-Repository liegt (nicht nur bei einem Hosting-Anbieter), ist sie nie wieder komplett verloren, selbst wenn ein Anbieter ausfällt oder eine Domain versehentlich ausläuft. GitHub behält die komplette Versionsgeschichte.

---

## Troubleshooting & FAQ

| Symptom | Fix |
|---|---|
| Claude Code findet Dateien/Ordner nicht | Ordner freigegeben? Platzhalter im Prompt ersetzt? |
| Texte klingen nach KI/Coach-Sprech | Nachschieben: "Schreib in meiner Sprache, kein 'Herzensbusiness'/'soulful', kurze direkte Sätze." |
| Seite zu lang, keiner liest bis zum Ende | "Kürz auf die Hälfte, behalte nur was Vertrauen oder Handlung auslöst." |
| Unsicher: One-Pager oder mehrseitig? | Ein Angebot → One-Pager. Mehrere Angebote/wachsende Marke → mehrseitig. |
| Bilder fehlen noch | Mit klaren Platzhaltern bauen lassen, Liste am Ende abfragen, was nachgeliefert werden muss |
| Endlose Rückfragen von Claude | Alle Infos aus Teil C nochmal komplett in einer Nachricht liefern: "Alles liegt jetzt vor. Lies erst, dann bau." |
| Website ist weg / Anbieter-Ausfall | Über GitHub Desktop lässt sich jede alte Version wiederherstellen – deshalb Teil A nie überspringen |

## Grundprinzip für jede Überarbeitung

Änderung an Text/Design → Claude Code sagen was sich ändern soll → Vorschau lokal oder direkt pushen → GitHub Desktop: Commit + Push → 30 Sek. → live. Kein erneuter kompletter Bau-Prompt nötig, nur die konkrete Änderung benennen.
