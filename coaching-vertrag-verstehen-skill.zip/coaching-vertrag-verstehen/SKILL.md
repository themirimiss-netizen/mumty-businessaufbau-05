---
name: coaching-vertrag-verstehen
description: Erklärt die Grundbausteine von Coaching-Verträgen, AGB, Widerrufsrecht und Impressum-Pflichten, damit du verstehst was ein Rechtstext-Anbieter liefert und worauf du achten musst. Eigenständiger Skill. Nutze diesen Skill für Verständnisfragen zu rechtlichen Basics rund um Coaching-Verträge – NICHT als Ersatz für echte Rechtsberatung.
---

# Coaching-Vertrag & AGB verstehen

**Wichtigste Regel zuerst: Dies ist Verständnishilfe, keine Rechtsberatung.** Verbindliche Vertragstexte müssen von einem Rechtstext-Anbieter (z.B. IT-Recht Kanzlei, e-recht24) oder einem echten Anwalt/einer echten Anwältin kommen. Dieser Skill hilft zu verstehen, WAS diese Texte enthalten und WARUM – nicht, sie selbst zu formulieren.

## Wann diesen Skill nutzen
- Du verstehst einen Passus in deinen AGB/deinem Coaching-Vertrag nicht
- Ein neues Angebot braucht einen angepassten Vertrag und du willst wissen, welche Bausteine dafür relevant sind
- Eine Kundin stellt eine Frage zum Vertrag, die du erst selbst einordnen willst

## Die Grundbausteine eines Coaching-Vertrags (zum Verständnis)

1. **Leistungsbeschreibung** – was genau ist Teil des Programms (Anzahl Calls, Zugang zu Material, Laufzeit). Je klarer, desto weniger Streit später.
2. **Zahlungsbedingungen** – Einmalzahlung vs. Ratenzahlung, was passiert bei Zahlungsverzug
3. **Laufzeit & Kündigung** – vor allem bei Ratenverträgen wichtig: kann man kündigen, während noch Raten offen sind?
4. **Widerrufsrecht** – bei Verbraucherinnen (nicht bei Gewerbetreibenden als Kundin) gilt in Deutschland grundsätzlich ein 14-tägiges Widerrufsrecht bei Fernabsatzverträgen. Wichtig: wenn mit dem Coaching sofort begonnen wird, kann eine ausdrückliche Zustimmung zum vorzeitigen Beginn UND ein Verzicht auf das Widerrufsrecht (bzw. anteilige Kostenerstattung) nötig sein – das MUSS rechtlich sauber formuliert sein, das ist ein häufiger Streitpunkt bei Coaching-Anbietern.
5. **Haftungsausschluss** – Coaching ist keine Heilbehandlung/Therapie, das sollte klar abgegrenzt sein, gerade wenn mit persönlicher Transformation gearbeitet wird
6. **Vertraulichkeit** – beidseitig, was in Calls besprochen wird bleibt vertraulich

## Impressum & Datenschutz – warum Pflicht
In Deutschland ist ein Impressum auf jeder gewerblichen Website Pflicht (Digitale-Dienste-Gesetz, Nachfolgeregelung des TMG), unabhängig von Umsatz oder Größe. Eine Datenschutzerklärung ist Pflicht, sobald personenbezogene Daten verarbeitet werden (das passiert praktisch immer, z.B. durch ein Kontaktformular oder Analyse-Tools).

## Was du selbst NICHT formulieren solltest
Jeden verbindlichen Rechtstext (AGB, Widerrufsbelehrung, Datenschutzerklärung) nicht selbst schreiben oder von Claude schreiben lassen – diese Texte müssen von einem Rechtstext-Anbieter oder Anwalt kommen und regelmäßig aktualisiert werden (Rechtsänderungen). Dieser Skill kann beim Verständnis helfen, nicht bei der rechtssicheren Formulierung.

## Wann ein Anwalt statt Standard-Anbieter nötig ist
Bei individuellen Streitfällen (z.B. eine Kundin fordert Geld zurück und beruft sich auf einen Passus), bei größeren Verträgen mit Sonderkonditionen, oder wenn eine Kundin selbst anwaltlich vertreten ist. Standard-Anbieter liefern Standardtexte, keine Einzelfall-Beratung.

## Prompt für Verständnisfragen

```
Ich hab in meinen AGB/meinem Vertrag folgenden Passus: [Text einfügen]
Erklär mir in einfachen Worten, was das bedeutet und wofür das da ist.
Sag mir auch, ob das eher Standard ist oder ob ich das lieber nochmal mit
einem Rechtstext-Anbieter/Anwalt klären sollte.
```
